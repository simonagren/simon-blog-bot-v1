import { ActivityHandler } from 'botbuilder';
export declare class SimonBot extends ActivityHandler {
    constructor();
}
